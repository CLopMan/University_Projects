f1 () {
    puts("HOLA mundo");
}

f2 () {
    int i;
    printf("f", "hola mundo: ", i);
}

main() {
    f1();
    f2();
}
//@ (main)
