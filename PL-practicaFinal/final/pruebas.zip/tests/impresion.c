int a = 1, b = 2;

main(){
    puts("Hola Mundo");
    printf("Primer parametro:%d Segundo parametro:%d", a, b);
    printf("Mezcla de string y expresiones", "Hola", a, "mundo", 1 + 1);
    puts("Adios Mundo");
}

//@ (main)
