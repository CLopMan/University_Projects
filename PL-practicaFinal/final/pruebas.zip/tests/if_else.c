int menor = 3;

main() {
    int mayor = 5;
    int abc = 1;

    if (mayor > 1) {
        puts("TRUE");
        printf("%d", mayor);
    }

    if (! (menor < mayor)) {
        puts("TRUE");
    } else {
        puts("FALSE");
    }

}
//@ (main)
