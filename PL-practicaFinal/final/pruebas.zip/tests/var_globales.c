int a;
int b = 0, c = 2;
int d, e, f, g;

main(){
    a = 1;
    d = 2 + 3;
    e = b;
    f = a + b + c;
    g = 2 + 3 * c;
}

//@ (main)
